require("./bootstrap");

require("./components/Cart");
require("./components/Checkout");
require("./components/ProductList");
require("./components/ProductShop");
require("./components/ProductDetail");
